package com.deameyesapps.GameLib;

public class MouseClick {
    int X;
    int Y;
    int Index;

    public  MouseClick(int X, int Y, int Index)
    {
        this.X = X;
        this.Y = Y;
        this.Index = Index;
    }
}
